PRML Assignment 1

By,
Karthikeyan S
CS21M028
N Kausik
CS21M037

Running the Codes:
cd into the current directory with all the Codes
Place the 4 dataset csv files in the same folder as the codes
If parameters are not given, input datasets will be taken from the current dir with names same as given in moodle.
If savepath is not given for the predictions file, it will be saved in the current dir as {question name}.csv

Q1)

a) Run the command:
python3 Q1_a.py {train_dataset_path} {test_dataset_path} {predictions_save_path}
or 
python3 Q1_a.py

b) Run the command:
python3 Q1_b.py {train_dataset_path} {test_dataset_path} {predictions_save_path}
or 
python3 Q1_b.py

c) Run the command:
python3 Q1_c.py {train_dataset_path} {test_dataset_path} {predictions_save_path}
or 
python3 Q1_c.py

Q2)

a) Run the command:
python3 Q2_a.py {train_dataset_path} {test_dataset_path} {predictions_save_path}
or 
python3 Q2_a.py

b) Run the command:
python3 Q2_b.py {train_dataset_path} {test_dataset_path} {predictions_save_path}
or 
python3 Q2_b.py

c) Run the command:
python3 Q2_c.py {train_dataset_path} {test_dataset_path} {predictions_save_path}
or 
python3 Q2_c.py

d) Run the command:
python3 Q2_d.py {train_dataset_path} {test_dataset_path} {predictions_save_path}
or 
python3 Q2_d.py